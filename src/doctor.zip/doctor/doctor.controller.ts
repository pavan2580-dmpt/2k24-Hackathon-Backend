import { Body, Controller, Get, Query } from '@nestjs/common';
import { DoctorService } from './doctor.service';
import { Param } from '@nestjs/common';
import { ReportDto } from './dto/report.dto';

@Controller('doctor')
export class DoctorController {
  constructor(private doctorService: DoctorService) {}
  @Get('getDoctorAppiontments/:doctorId')
  getDoctorWithAppiontments(@Param('doctorId') doctorId: string) {
    return this.doctorService.getDoctorWithAppiontments(doctorId);
  }

  @Get('getReports/:patientId')
  getReports(@Param('patientId') patientId: string) {
    return this.doctorService.getReports(patientId);
  }

  @Get('updateReports/:patientId')
  updateReports(
    @Param('patientId') patientId: string,
    @Body('request') request: ReportDto,
  ) {
    return this.doctorService.updateReports(patientId, request);
  }
}
