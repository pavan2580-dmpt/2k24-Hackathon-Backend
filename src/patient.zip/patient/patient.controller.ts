import { Controller, Param, Post } from '@nestjs/common';
import { PatientService } from './patient.service';
import { CreateAppointmentDto } from './dto/appointment.dto';

@Controller('patient')
export class PatientController {
  constructor(private patientService: PatientService) {}

  @Post(':patientId/addAppointment/:doctorId')
  addAppointment(
    @Param('patientId') patientId: string,
    @Param('doctorId') doctorId: string,
    request: CreateAppointmentDto,
  ) {
    return this.patientService.addAppointment(patientId, doctorId, request);
  }
}
